<?php
header('Location: /portal/home.php');