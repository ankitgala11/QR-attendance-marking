<footer class="footer mt-5">
    <div class="p-3 col-12 border bg-light shadow">
        <div class="d-flex flex-wrap pb-1" style="padding-bottom: 20px;">
            <div class="col-6"><?= $appName ?></div>
            <div class="col-6 fw-bold text-muted text-end">Developed By HelloWorld</div>
        </div>
    </div>
</footer>

<?php unset($_SESSION['alert']); ?>